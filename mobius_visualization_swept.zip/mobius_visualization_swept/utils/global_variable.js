// declaring all of the global variables in this file


// parameters 



// functions

// charts

// global variables
 



var energy;
var colEnergy;
var ind_energy;
 







var chart;  // Declare chart variable
var chartK;  // Declare chart variable
var createChart;
var createchartK;
var pushDataset;
var deleteDataset;
var linspace;



// initial values 
var N;
var n = 3;
var nMax = 75;
var hl = 0.2;
var speedy = 0.01;
var k = 0;
var play = false;
var refresh = false;
var colorScheme = 1;
var maxColor = 2;

 

var hx0;
var hy0;
var hz0;

var tx0;
var ty0;
var tz0;

var rx0;
var ry0;
var rz0;



var rx;
var ry;
var rz;

var nu_i;

var nu_min = 1;
var nu_max = 24;
var nu_opt = 1;


var parameters = [[3, 1, 1, 24],
[5, 25, 70, 93],
[7, 94, 135, 160],
[9, 161, 199, 224],
[11, 225, 262, 288],
[13, 289, 325, 351],
[15, 352, 388, 414],
[17, 415, 449, 476],
[19, 477, 511, 539],
[21, 540, 573, 600],
[23, 601, 634, 662],
[25, 663, 695, 722],
[27, 723, 756, 770]];;  // parameters n N and tau 


var kappa;



var numData;
 
 
var N;
var N1;

var Pi = Math.PI;
var tau;
var n;
var h;
var kappa0 = [];  // curvature of the midline at time t = 0
var kappa = [];  // curvature of the midline at time t = 0

var  midlineInit;

var nui_to_n;
var n_to_nui;


 
